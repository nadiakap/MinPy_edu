import numpy as np

class Minimization:
    def __init__(self, func, X0, K=30, lb=None, ub=None, tol=1e-6):
        self.get_f = func
        self.dim = len(X0)
        self.lb = np.array(lb) if lb is not None else np.full(self.dim, -np.inf)
        self.ub = np.array(ub) if ub is not None else np.full(self.dim, np.inf)
        self.tol = tol
        self.u = np.random.uniform(self.lb, self.ub, (K, self.dim))
        self.fu = np.array([self.get_f(u) for u in self.u])

    def best(self):
        idx = np.argmin(self.fu)
        return self.fu[idx], self.u[idx]
