from minpy import Minimization, optfun
import numpy as np

def test_ackley_minimization():
    m = Minimization(optfun.ackley, X0=np.zeros(2), K=40, lb=[-5, -5], ub=[5, 5])
    fbest, xbest = m.minimize_potential_nonlocal(max_epochs=5)
    assert fbest < 1.0
