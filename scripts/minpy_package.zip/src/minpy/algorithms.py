import numpy as np

def minimize_potential_nonlocal(self, max_epochs=100, verbose=False):
    for epoch in range(max_epochs):
        idx = np.argmin(self.fu)
        best_u = self.u[idx]
        self.u += -0.1 * (self.u - best_u)
        self.fu = np.array([self.get_f(u) for u in self.u])
        if verbose:
            print(f"Epoch {epoch+1}: best f = {self.fu[idx]:.6f}")
    return self.best()

def minimize_potential_second_order(self, max_epochs=100, verbose=False):
    for epoch in range(max_epochs):
        idx = np.argmin(self.fu)
        best_u = self.u[idx]
        self.u += -0.1 * (self.u - best_u) - 0.05 * np.random.randn(*self.u.shape)
        self.fu = np.array([self.get_f(u) for u in self.u])
        if verbose:
            print(f"Epoch {epoch+1}: best f = {self.fu[idx]:.6f}")
    return self.best()
