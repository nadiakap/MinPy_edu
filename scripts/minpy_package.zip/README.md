# MinPy Optimization Library

Implements nonlocal optimization based on potential theory.