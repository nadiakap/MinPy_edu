from minpy import Minimization, optfun
import numpy as np

m = Minimization(optfun.ackley, X0=np.zeros(2), K=50, lb=[-5,-5], ub=[5,5])
best_f, best_x = m.minimize_potential_nonlocal(max_epochs=100, verbose=True)

print("Ackley best value:", best_f)
print("At point:", best_x)
