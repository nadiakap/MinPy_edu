import numpy as np

def diminishing_lr(lr0, k, alpha=0.5):
    return lr0 / (1 + k)**alpha

def estimate_gradient_noise(grad_samples):
    if len(grad_samples) < 2:
        return 0.0
    return float(np.mean(np.var(np.stack(grad_samples, axis=0), axis=0)))

def estimate_local_curvature(f_grad, w, eps=1e-6):
    w = np.asarray(w)
    _, g1 = f_grad(w)
    _, g2 = f_grad(w + eps)
    diff = g2 - g1
    return float(np.sum(np.abs(diff)) / (eps * len(w)))
