import numpy as np

import matplotlib.pyplot as plt

def diminishing_lr(lr0, k, alpha=0.5):
    return lr0 / (1 + k)**alpha

def estimate_gradient_noise(grad_samples):
    if len(grad_samples) < 2:
        return 0.0
    return float(np.mean(np.var(np.stack(grad_samples, axis=0), axis=0)))

def estimate_local_curvature(f_grad, w, eps=1e-6):
    w = np.asarray(w)
    _, g1 = f_grad(w)
    _, g2 = f_grad(w + eps)
    diff = g2 - g1
    return float(np.sum(np.abs(diff)) / (eps * len(w)))

def make_regression_objective(X, y, model, loss, eps=1e-6):
    """
    Build an (f, grad) callable for regression problems.
    Uses finite differences to estimate gradient of the loss.
    """
    X = np.asarray(X)
    y = np.asarray(y)

    def f_grad(w):
        w = np.asarray(w)
        y_pred = model(w, X)
        fval = loss(y, y_pred)
        grad = np.zeros_like(w)
        for i in range(len(w)):
            w_pert = w.copy()
            w_pert[i] += eps
            y_pert = model(w_pert, X)
            f_pert = loss(y, y_pert)
            grad[i] = (f_pert - fval) / eps
        return fval, grad

    return f_grad



def plot_objective(f, x_range=(-2, 2), y_range=(-2, 2), n_grid=50,
                   title=None, show=True, levels=20, view_3d=False):
    """
    Visualize a 2D objective function f([x, y]).
    Parameters:
        f        : callable(w) -> scalar
        x_range  : (min, max)
        y_range  : (min, max)
        n_grid   : resolution
        title    : optional plot title
        levels   : number of contour levels
        view_3d  : if True, show 3D surface instead of contour
    """
    x = np.linspace(*x_range, n_grid)
    y = np.linspace(*y_range, n_grid)
    X, Y = np.meshgrid(x, y)
    Z = np.zeros_like(X)
    for i in range(n_grid):
        for j in range(n_grid):
            Z[i, j] = f(np.array([X[i, j], Y[i, j]]))

    fig = plt.figure(figsize=(6, 5))
    if view_3d:
        from mpl_toolkits.mplot3d import Axes3D  # noqa
        ax = fig.add_subplot(111, projection='3d')
        ax.plot_surface(X, Y, Z, cmap='viridis', edgecolor='none', alpha=0.8)
        ax.set_xlabel('w1')
        ax.set_ylabel('w2')
        ax.set_zlabel('f(w)')
    else:
        cp = plt.contourf(X, Y, Z, levels=levels, cmap='viridis')
        plt.xlabel('w1')
        plt.ylabel('w2')
        plt.colorbar(cp)
    if title:
        plt.title(title)
    if show:
        plt.show()
    return fig

