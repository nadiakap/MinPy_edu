import numpy as np
from scipy.linalg import inv, toeplitz

def identity_kernel(n):
    return np.eye(n)

def diffusion_kernel(n, sigma=0.5):
    r = np.arange(n)
    K = np.exp(-(r[:, None] - r[None, :])**2 / (2 * sigma**2))
    K /= K.sum(axis=1, keepdims=True)
    return K

def greens_kernel(n, alpha=0.3):
    if n == 1:
        return np.array([[1.0]])
    lap = toeplitz([2, -1] + [0]*(n-2))
    lap[-1, -2] = -1
    lap[-1, -1] = 1
    K = inv(np.eye(n) * alpha + lap)
    K = K / (np.max(np.abs(K)) + 1e-12)
    return K

def elliptic_kernel(n, stiffness=1.0):
    return greens_kernel(n, alpha=1.0/stiffness)

def wave_propagation_kernel(n, c=1.0):
    x = np.arange(n)
    K = np.cos(c * np.pi * (np.outer(x, x) % (n+1)) / (n+1))
    K = K / (np.max(np.abs(K)) + 1e-12)
    return K
