"""MinPy-Edu: Educational optimization library.
Version 1.0.0-edu
Backward-compatibility: users can still `import minpy` which will alias to this package.
"""
__version__ = "1.0.0-edu"
from .kernels import identity_kernel, diffusion_kernel, greens_kernel, elliptic_kernel, wave_propagation_kernel
from .continuous import kaplinski_optimize
from .discrete import KES, KNM, CKD
from .utils import diminishing_lr, estimate_gradient_noise, estimate_local_curvature
try:
    import sys
    sys.modules['minpy'] = sys.modules[__name__]
except Exception:
    pass
