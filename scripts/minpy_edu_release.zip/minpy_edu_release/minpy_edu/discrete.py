import numpy as np
from .kernels import identity_kernel

def default_weights(N):
    w = np.zeros(N)
    top = max(1, N//4)
    w[:top] = np.linspace(1.0, 0.2, top)
    return w / w.sum() if w.sum() != 0 else np.ones(N) / N

def KES(f, m0, kernel_op=identity_kernel, sigma0=0.2, N=40, lr0=0.2, max_iter=200, seed=None):
    if seed is not None:
        np.random.seed(seed)
    m = np.array(m0, dtype=float)
    n = m.size
    history = [m.copy()]
    weights = default_weights(N)
    for k in range(max_iter):
        sigma = sigma0 / (1 + k)**0.25
        X = m + sigma * np.random.randn(N, n)
        vals = np.array([f(x) for x in X])
        idx = np.argsort(vals)
        ordered = X[idx]
        w = weights
        g = np.sum((w[:, None] * (ordered - m)), axis=0) / sigma
        K = kernel_op(n) if callable(kernel_op) else kernel_op
        lr = lr0 / (1 + k*0.01)
        m = m - lr * K.dot(g)
        history.append(m.copy())
    return m, np.array(history)

def KNM(f, simplex_init, kernel_op=identity_kernel, alpha=1.0, gamma=0.5, tol=1e-6, max_iter=500):
    simplex = [np.array(s, dtype=float) for s in simplex_init]
    n = simplex[0].size
    for k in range(max_iter):
        simplex.sort(key=lambda x: float(f(x)))
        best = simplex[0]
        worst = simplex[-1]
        K = kernel_op(n) if callable(kernel_op) else kernel_op
        centroid = sum(K.dot(x) for x in simplex[:-1]) / n
        x_ref = worst + alpha * (centroid - worst)
        if f(x_ref) < f(worst):
            simplex[-1] = x_ref
        else:
            for i in range(1, len(simplex)):
                simplex[i] = best + gamma * (simplex[i] - best)
        pts = np.stack(simplex)
        diam = np.max(np.linalg.norm(pts - pts.mean(axis=0), axis=1))
        if diam < tol:
            break
    simplex.sort(key=lambda x: float(f(x)))
    return simplex[0]

def CKD(f_grad, w0s, W_fn, kernel_op=identity_kernel, lr0=0.1, max_iter=200):
    w = np.array([np.array(x, dtype=float) for x in w0s])
    N, n = w.shape
    history = [w.copy()]
    for k in range(max_iter):
        W = W_fn(w)
        K = kernel_op(n) if callable(kernel_op) else kernel_op
        grads = np.array([f_grad(wi) for wi in w])
        y = np.array([wi - lr0 * K.dot(g) for wi, g in zip(w, grads)])
        w = W.dot(y)
        history.append(w.copy())
    avg = history[-1].mean(axis=0)
    return avg, np.array(history)
