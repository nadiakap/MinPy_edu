import numpy as np

class DiscreteObjective:
    def __init__(self, cost_function, space_size):
        """
        cost_function: function(state) -> scalar cost
        space_size: dimension of the problem (e.g., number of cities in TSP)
        """
        self.cost = cost_function
        self.n = space_size

    def evaluate(self, state):
        """Returns the cost of a discrete state."""
        return self.cost(state)


def kaplinsky_discrete_optimize(
        discrete_obj,
        initial_state,
        update_operator,
        max_iter=1000,
        accept_worse=False,
        temperature=1.0,
        return_history=False):
    """
    Kaplinsky-style discrete optimization.

    Parameters:
    -----------
    discrete_obj : DiscreteObjective
        Provides cost evaluation.
    initial_state : array-like
        Initial permutation or assignment.
    update_operator : function(state) -> new_state
        Discrete 'kernel' move (swap, 2-opt, reassignment, etc.).
    max_iter : int
        Maximum number of iterations.
    accept_worse : bool
        If True, may accept worse solutions (simulated annealing).
    temperature : float
        Controls probability of accepting worse moves.
    return_history : bool
        If True, returns list of (state, cost) at each iteration.

    Returns:
    --------
    best_state, best_cost          (if return_history=False)
    best_state, best_cost, history (if return_history=True)
    """

    # Ensure numpy format
    state = np.array(initial_state).copy()
    current_cost = discrete_obj.evaluate(state)

    best_state = state.copy()
    best_cost = current_cost

    history = []

    for k in range(max_iter):

        # Apply discrete kernel / update operator
        new_state = update_operator(state)
        new_cost = discrete_obj.evaluate(new_state)

        # Save to history if needed
        if return_history:
            history.append((new_state.copy(), new_cost))

        # Accept if better:
        if new_cost < current_cost:
            state = new_state
            current_cost = new_cost

            # Update global best
            if new_cost < best_cost:
                best_cost = new_cost
                best_state = new_state.copy()

        # Optionally accept worse solutions
        elif accept_worse:
            prob = np.exp(-(new_cost - current_cost) / temperature)
            if np.random.rand() < prob:
                state = new_state
                current_cost = new_cost

    if return_history:
        return best_state, best_cost, history
    else:
        return best_state, best_cost

# === Discrete “kernels” / update operators ===

def swap_operator(state):
    """
    Randomly swaps two positions in the state (permutation).
    Works for TSP, assignment vector, general permutations.
    """
    new_state = state.copy()
    i, j = np.random.randint(0, len(state), 2)
    new_state[i], new_state[j] = new_state[j], new_state[i]
    return new_state

def two_opt_operator(state):
    """
    2-opt move: reverse a random subsequence (common in TSP).
    """
    new_state = state.copy()
    i, j = np.sort(np.random.randint(0, len(state), 2))
    if i == j:
        return new_state
    new_state[i:j] = new_state[i:j][::-1]
    return new_state

def assignment_swap_operator(state):
    """
    For assignment problems: same as swap, but semantically clearer.
    """
    return swap_operator(state)

def kaplinsky_discrete_anneal(discrete_obj,
                              initial_state,
                              update_operator,
                              max_iter=2000,
                              T_start=1.0,
                              T_end=0.001,
                              return_history=False):
    """
    Kaplinsky-style discrete optimization WITH simulated annealing.
    T decreases gradually from T_start to T_end.
    """
    state = np.array(initial_state).copy()
    current_cost = discrete_obj.evaluate(state)
    best_state = state.copy()
    best_cost = current_cost

    history = []
    for k in range(max_iter):
        T = T_start * (T_end / T_start)**(k / max_iter)  # exponential cooling

        new_state = update_operator(state)
        new_cost = discrete_obj.evaluate(new_state)

        if return_history:
            history.append((new_state.copy(), new_cost, T))

        # Accept if better
        if new_cost < current_cost:
            state, current_cost = new_state, new_cost
            if new_cost < best_cost:
                best_cost = new_cost
                best_state = new_state.copy()
        else:
            # Accept with probability exp(-(Δ)/T)
            prob = np.exp(-(new_cost - current_cost) / max(T, 1e-12))
            if np.random.rand() < prob:
                state, current_cost = new_state, new_cost

    return (best_state, best_cost, history) if return_history else (best_state, best_cost)
