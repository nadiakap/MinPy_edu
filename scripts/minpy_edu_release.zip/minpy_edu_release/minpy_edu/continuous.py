import numpy as np
from .kernels import identity_kernel
from .utils import estimate_gradient_noise, estimate_local_curvature

def kaplinski_optimize(f_grad, w0, update_operator='auto', lr=0.1, max_iter=200, tol=1e-6):
    w = np.array(w0, dtype=float)
    n = w.size
    path = [w.copy()]
    grad_samples = []
    for k in range(max_iter):
        fval, grad = f_grad(w)
        grad_samples.append(grad)
        if len(grad_samples) > 5:
            grad_samples.pop(0)
        if callable(update_operator):
            kernel_fn = update_operator
        else:
            if update_operator == 'auto':
                noise = estimate_gradient_noise(grad_samples)
                curvature = estimate_local_curvature(f_grad, w)
                if noise > 1e-2:
                    from .kernels import diffusion_kernel
                    kernel_fn = lambda n: diffusion_kernel(n, sigma=0.7)
                elif curvature > 1e2:
                    from .kernels import greens_kernel
                    kernel_fn = lambda n: greens_kernel(n, alpha=0.5)
                else:
                    kernel_fn = identity_kernel
            elif update_operator == 'diffusion':
                from .kernels import diffusion_kernel
                kernel_fn = lambda n: diffusion_kernel(n, sigma=0.5)
            elif update_operator == 'greens':
                from .kernels import greens_kernel
                kernel_fn = lambda n: greens_kernel(n, alpha=0.3)
            else:
                kernel_fn = identity_kernel
        K = kernel_fn(n)
        step = -lr * K.dot(grad)
        w = w + step
        path.append(w.copy())
        if np.linalg.norm(step) < tol:
            break
    return np.array(path)
