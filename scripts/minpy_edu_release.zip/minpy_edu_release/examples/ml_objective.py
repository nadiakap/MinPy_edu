#linear regression objective
import numpy as np
from minpy_edu import kaplinski_optimize, make_regression_objective

# synthetic data
X = np.random.randn(100, 2)
true_w = np.array([2.0, -3.0])
y = X @ true_w + 0.5 * np.random.randn(100)


#X @ w  - matrix multiplication
def model(w, X): return X @ w

#
def loss(y_true, y_pred): return np.mean((y_true - y_pred)**2)

f_grad = make_regression_objective(X, y, model, loss)
path = kaplinski_optimize(f_grad, w0=[0,0], update_operator='auto')
print("Estimated weights:", path[-1])
