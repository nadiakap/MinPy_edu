from minpy_edu import DiscreteObjective, kaplinsky_discrete_anneal,swap_operator

import numpy as np

def assignment_cost(assign, cost_matrix):
    return sum(cost_matrix[i, assign[i]] for i in range(len(assign)))


def assignment_cost_fn(assign, cost_matrix):
    return sum(cost_matrix[i, assign[i]] for i in range(len(assign)))

def example_assignment():
    '''Cost matrix C[i][j] = cost of assigning worker i to job j

     State = permutation array, e.g. [2, 0, 1] → worker 0 → job 2, etc.

    '''
    cost_matrix = np.array([
        [9, 2, 7, 8],
        [6, 4, 3, 7],
        [5, 8, 1, 8],
        [7, 6, 9, 4]
    ])
    n = cost_matrix.shape[0]

    obj = DiscreteObjective(lambda a: assignment_cost_fn(a, cost_matrix), n)
    initial = np.arange(n)

    best_state, best_cost = kaplinsky_discrete_anneal(
        obj, initial, swap_operator,
        max_iter=2000, T_start=1.0, T_end=0.001
    )

    print("Best assignment:", best_state)
    print("Cost:", best_cost)
