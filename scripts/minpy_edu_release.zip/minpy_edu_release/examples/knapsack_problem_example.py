from minpy_edu import DiscreteObjective, kaplinsky_discrete_anneal

import numpy as np

def knapsack_cost(state, values, weights, capacity):
    total_weight = np.dot(state, weights)
    total_value = np.dot(state, values)
    if total_weight > capacity:
        return 1e6 + (total_weight - capacity) * 1000  # heavy penalty
    return -total_value  # convert maximization to minimization

def flip_bit_operator(state):
    new_state = state.copy()
    i = np.random.randint(len(state))
    new_state[i] = 1 - new_state[i]
    return new_state

def example_knapsack():
    '''You have n items, each with weight w[i] and value v[i]
    Capacity = W
    State representation = binary vector (0 = not taken, 1 = taken)
    '''
    values = np.array([10, 5, 15, 7, 6, 18, 3])
    weights = np.array([2, 3, 5, 7, 1, 4, 1])
    capacity = 15
    n = len(values)

    cost_fn = lambda s: knapsack_cost(s, values, weights, capacity)
    obj = DiscreteObjective(cost_fn, n)

    initial_state = np.zeros(n, dtype=int)

    best_state, best_cost = kaplinsky_discrete_anneal(
        obj, initial_state, flip_bit_operator,
        max_iter=2000, T_start=1.0, T_end=0.001
    )

    print("Best knapsack configuration:", best_state)
    print("Total value:", -best_cost)
