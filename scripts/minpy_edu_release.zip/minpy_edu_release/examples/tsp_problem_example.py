import numpy as np
import matplotlib.pyplot as plt

from minpy_edu import DiscreteObjective, kaplinsky_discrete_optimize


# ----------------------------------------------------
# 2. Discrete update operator: 2-opt (TSP-specific)
# ----------------------------------------------------
def two_opt_operator(route):
    new_route = route.copy()
    i, j = np.sort(np.random.randint(0, len(route), 2))
    if i < j:
        new_route[i:j] = route[i:j][::-1]
    return new_route

# ----------------------------------------------------
# 3. TSP Cost Function
# ----------------------------------------------------
def tsp_cost(route, distance_matrix):
    cost = 0.0
    n = len(route)
    for i in range(n):
        cost += distance_matrix[route[i], route[(i + 1) % n]]
    return cost

# ----------------------------------------------------
# 4. Generate random TSP instance
# ----------------------------------------------------
def generate_random_cities(n=12, seed=0):
    np.random.seed(seed)
    return np.random.rand(n, 2) * 10  # random points in 10x10 square

def compute_distance_matrix(cities):
    n = len(cities)
    D = np.zeros((n, n))
    for i in range(n):
        for j in range(n):
            D[i, j] = np.linalg.norm(cities[i] - cities[j])
    return D

# ----------------------------------------------------
# 5. Run TSP with Kaplinsky discrete optimizer
# ----------------------------------------------------
def solve_tsp_kaplinsky(n_cities=12, max_iter=2000, accept_worse=False):
    cities = generate_random_cities(n_cities, seed=0)
    D = compute_distance_matrix(cities)
    
    initial_route = np.arange(n_cities)  # simple ordered start

    obj = DiscreteObjective(
        cost_function=lambda r: tsp_cost(r, D),
        space_size=n_cities
    )

    best_route, best_cost = kaplinsky_discrete_optimize(
        obj,
        initial_route,
        two_opt_operator,
        max_iter=max_iter,
        accept_worse=accept_worse,
        temperature=1.0,
        return_history=False
    )

    return cities, best_route, best_cost

# ----------------------------------------------------
# 6. Visualization
# ----------------------------------------------------
def plot_tsp_route(cities, route, title="TSP Route"):
    plt.figure(figsize=(6, 6))
    plt.scatter(cities[:, 0], cities[:, 1], c='black')
    
    ordered = cities[route]
    closed = np.vstack([ordered, ordered[0]])  # close the loop

    plt.plot(closed[:, 0], closed[:, 1], '-o')
    for idx, (x, y) in enumerate(cities):
        plt.text(x + 0.1, y + 0.1, str(idx), fontsize=9)
    
    plt.title(title)
    plt.show()

# ----------------------------------------------------
# 7. Example Usage
# ----------------------------------------------------
if __name__ == "__main__":
    cities, route, cost = solve_tsp_kaplinsky(
        n_cities=12,
        max_iter=3000,
        accept_worse=False
    )

    print("Best route found:", route)
    print("Total distance:", cost)

    plot_tsp_route(cities, route, title=f"Kaplinsky TSP (Cost={cost:.2f})")
