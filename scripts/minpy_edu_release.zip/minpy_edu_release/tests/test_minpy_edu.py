import numpy as np
from minpy_edu import kaplinski_optimize, KES, greens_kernel

def test_continuous_quadratic():
    def fg(w): return 0.5 * np.dot(w, w), w
    path = kaplinski_optimize(fg, [1.0, -1.0], update_operator='identity', lr=0.1, max_iter=20)
    assert len(path) > 1

def test_kes_reduces():
    def f(x): return 0.5 * np.dot(x, x)
    m, _ = KES(f, [2.0, -1.0], kernel_op=greens_kernel, sigma0=0.2, N=20, lr0=0.1, max_iter=40, seed=0)
    assert f(m) < f([2.0, -1.0])
