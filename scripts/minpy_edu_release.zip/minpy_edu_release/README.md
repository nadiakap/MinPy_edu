# MinPy-Edu 1.0.0-edu

Educational optimization library for research and teaching.
Based on the method of Kaplinski & Propoi (1994). Presented at SciPy 2022 ("Global Optimization Software Library for Research and Education").

Repository: https://github.com/nadiakap/MinPy_edu

Use:
```python
import minpy_edu
print(minpy_edu.__version__)
```

Note: For backward compatibility, `import minpy` will also import this package.
